package com.HyundaiModule.test;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;

import com.Hyundai.Utilities.Utilities;

public class HyundaiBookaCar extends Utilities {

	@FindBy(xpath = "//div[@class='row m-0 hboxshad']")
	public WebElement Logo;

	@FindBy(xpath = "//select[@id='inputmodel-01']")
	public WebElement CarModel;

	@FindBy(xpath = "//select[@id='inputfuel-01']")
	public WebElement FuelType;

	@FindBy(xpath = "//select[@id='inputvrnt-01']")
	public WebElement Variant;

	@FindBy(xpath = "//select[@id='inputext-01'] ")
	public WebElement Exterior;

	@FindBy(xpath = "//select[@id='inputinter-01'] ")
	public WebElement Interior;

	@FindBy(xpath = "//select[@id='state-01']")
	public WebElement StateDropDown;

	@FindBy(xpath = "//select[@id='state-01']//following-sibling::option")
	public WebElement StateList;

	@FindBy(xpath = "//select[@id='dealer-city-01']")
	public WebElement CityDropDown;

	@FindBy(xpath = "//select[@id='dealer-city-01']//following-sibling::option")
	public String CityList;

	@FindBy(xpath = "//select[@id='bookacardelar']//option")
	public WebElement DealerName;

	@FindBy(xpath = "//div[@class='tit ico-bullet']")
	public WebElement DealerAvailability;

	@FindBy(xpath = "//li[@class='ico-address']")
	public WebElement DealerAddress;

	@FindBy(xpath = "//li[@class='ico-phone']")
	public WebElement DealerPhone;

	@FindBy(xpath = "//li[@class='ico-hours']")
	public WebElement DealerHours;

	@FindBy(xpath = "//li[contains(@class,'dealer-info')]")
	public WebElement DealerInfo;

	public WebDriver driver;
	WebDriverWait wait;

	private static Logger logger = LogManager.getLogger(HyundaiBookaCar.class);

	public HyundaiBookaCar(WebDriver driver, WebDriverWait wait) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	// Selecting Model
	public void SelectModel(String Model) {
		try {
			Utilities.WaitElementToBeClickable(CarModel);
			Utilities.WaitElementToBeClickable(CarModel);
			selectByValue(CarModel, Model);
			logger.info("User Selected Model successfully");
		} catch (Exception ex) {
			logger.info("Model selection gets failed");
		}
	}

	// Selecting FuelType
	public void SelectFuel(String Fuel) {
		try {
			selectByValue(FuelType, Fuel);
			logger.info("User Selected fuel type successfully");
		} catch (Exception ex) {
			logger.info("Fuel selection gets failed");
		}
	}

	// Selecting Variant
	public void SelectVariant(String variant) {
		try {
			selectByValue(Variant, variant);
			logger.info("User Selected variant successfully");
		} catch (Exception ex) {
			logger.info("Variant selection gets failed");
		}
	}

	// Selecting Exterior color
	public void SelectExteriorColor(String ExteriorColor) {
		try {
			selectByValue(Exterior, ExteriorColor);
			logger.info("User Selected exterior color successfully");
		} catch (Exception ex) {
			logger.info("Exterior color selection gets failed");
		}
	}

	// Selecting Interior color
	public void SelectInteriorColor(String InteriorColor) {
		try {
			selectByValue(Interior, InteriorColor);
			logger.info("User Selected interior color successfully");
		} catch (Exception ex) {
			logger.info("Interior color selection gets failed");
		}
	}

	// Selecting State
	public void SelectState(String State) {
		try {
			//selectByValue(StateDropDown, State);
			logger.info("User Selected state successfully");
		} catch (Exception ex) {
			logger.info("State selection gets failed");
		}
	}

	// Selecting State
	public void SelectCity(String city) {
		try {
			//selectByValue(StateDropDown, city);
			logger.info("User Selected city successfully");
		} catch (Exception ex) {
			logger.info("City selection gets failed");
		}
	}

	// Selecting State
	public void SelectDealer(String dealer) {
		try {
			
			selectByValue(DealerName, dealer);
			logger.info("User Selected dealer successfully");
		} catch (Exception ex) {
			logger.info("Dealer selection gets failed");
		}
	}

	// Selecting City
	public void SelectStateCityDealer(String State,String City) {
		try {
			selectByValue(StateDropDown, State);
			
//			WebElement dropdown = driver.findElement(By.xpath(StateDropDown));
//	        dropdown.click();
//	        
//	        WebElement option = dropdown.findElement(By.xpath(".//option[text()='" + City + "']"));
//	        option.click();
//	        
			TapElement(CityDropDown);
			List<WebElement> Cities = driver.findElements(By.xpath(CityList));
			for (WebElement citySelection : Cities) {
				String CityFound = citySelection.getText();
				if (CityFound.equals(City)) {
					TapElement(citySelection);
					TapElement(DealerName);
					String getDealerShipName = DealerAvailability.getText();

					if (getDealerShipName.equalsIgnoreCase("Dealership not selected."))
						System.out.println("Dealership is not available");
					else
						System.out.println("Dealership is available and here are the details");
					System.out.println(getDealerShipName);
					String getDealerAddress = DealerAddress.getText();
					String getDealerPhone = DealerPhone.getText();
					String getHours = DealerHours.getText();
					String getDealerWorkingHours = DealerInfo.getText();
					System.out.println(getDealerAddress);
					System.out.println(getDealerPhone);
					System.out.println(getHours);
					System.out.println(getDealerWorkingHours);
				}
			}
			logger.info("User Selected City successfully");
		} catch (Exception ex) {
			logger.info("City selection gets failed");
		}
	}

}
