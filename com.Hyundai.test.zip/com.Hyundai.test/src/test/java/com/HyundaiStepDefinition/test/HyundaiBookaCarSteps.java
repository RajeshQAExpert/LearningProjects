package com.HyundaiStepDefinition.test;

import java.io.File;
import java.util.List;
import java.util.Properties;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import com.Hyundai.Utilities.Utilities;
import com.HyundaiModule.test.HyundaiBookaCar;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class HyundaiBookaCarSteps extends Utilities {

	private WebDriver driver = null;
	public HyundaiBookaCar hyundaiBookaCar;
	private static Logger logger = LogManager.getLogger(HyundaiBookaCarSteps.class);
	SoftAssert softassert = new SoftAssert();
	File folder;

	Properties Hyundai = Utilities.loadProperty(HYUNDAI);

	public HyundaiBookaCarSteps() throws Exception {
		this.driver = Utilities.initiateApp();
	}

	@Given("user landed on Hyundai car booking page")
	public void user_landed_on_hyundai_car_booking_page() {
		hyundaiBookaCar = new HyundaiBookaCar(driver, wait);
		String value = hyundaiBookaCar.Logo.getAttribute("class");
		System.out.println(value);
		if (value == "row m-0 hboxshad")
			Assert.assertTrue(true);
		logger.info("User landed on Hyundai application");
	}

	@When("selecting model,fuel type and variant")
	public void selecting_model_fuel_type_and_variant() {
		hyundaiBookaCar = new HyundaiBookaCar(driver, wait);
		hyundaiBookaCar.SelectModel(Hyundai.getProperty("MODEL"));
		hyundaiBookaCar.SelectFuel(Hyundai.getProperty("FUEL"));
		hyundaiBookaCar.SelectVariant(Hyundai.getProperty("VARIANT"));
	}

	@Then("Exterior color should be select")
	public void exterior_color_should_be_select() {
		hyundaiBookaCar = new HyundaiBookaCar(driver, wait);
		hyundaiBookaCar.SelectExteriorColor(Hyundai.getProperty("EXTERIORCOLOR"));
	}

	@And("I have selected Interior color")
	public void i_Have_Selected_Interior_Color() {
		hyundaiBookaCar = new HyundaiBookaCar(driver, wait);
		hyundaiBookaCar.SelectInteriorColor(Hyundai.getProperty("INTERIORCOLOR"));
	}

	@When("I select state from the Dealer State dropdown")
	public void i_select_state_from_the_dealer_state_dropdown() {
		//hyundaiBookaCar = new HyundaiBookaCar(driver, wait);
		//hyundaiBookaCar.SelectState(Hyundai.getProperty("INTERIORCOLOR"));
	}

	@When("I select city from the Dealer City dropdown")
	public void i_select_city_from_the_dealer_city_dropdown() {
		hyundaiBookaCar = new HyundaiBookaCar(driver, wait);
		hyundaiBookaCar.SelectStateCityDealer(Hyundai.getProperty("STATE1"), Hyundai.getProperty("CITY1"));
	}

	@When("I select the first dealer from the Dealer Name dropdown")
	public void i_Select_First_Dealer_From_Dropdown() {
		hyundaiBookaCar = new HyundaiBookaCar(driver, wait);
		//hyundaiBookaCar.SelectDealer();
	}

	@When("I capture and print the dealer name displayed under the image")
	public void iCaptureAndPrintDealerName() {

	}

	@Then("I should see the dealer name printed in the console")
	public void i_Should_See_Dealer_Name_Printed() {

	}



}
