package com.Hyundai.Utilities;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.TimeUnit;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Utilities implements IAutoConstant {

	public static Properties property;
	public static int elementWaitInSeconds = 10;
	public static WebDriverWait wait;
	public static String getUserInput;
	public static WebDriver driver;
	public static String url;
	public static BufferedReader reader;
	public static ChromeOptions options;
	String folder;
	public static String DefaultDirectory;

	private static Logger logger = LogManager.getLogger(Utilities.class);

	public static WebDriver initiateApp() throws Exception {

		
		property = loadProperty(HYUNDAI);
		getUserInput = property.getProperty("USERINPUT");
		url = property.getProperty("URL");
		
		try {
			if (getUserInput.equalsIgnoreCase("Chrome")) {
				WebDriverManager.chromedriver().setup();
				options = new ChromeOptions();				
				driver = new ChromeDriver(options);
				driver.manage().window().maximize();
				driver.get(url);
			}

			driver.manage().timeouts().implicitlyWait(elementWaitInSeconds, TimeUnit.SECONDS);
			logger.info("Hyundai application gets started");

		} catch (Exception ex) {
			logger.error("Hyundai app not started");
		}
		return driver;
	}
	
	public static void terminateApp() {
		try {
			driver.quit();
			logger.info("Hyundai app closed");
		} catch (Exception ex) {
			logger.error("Hyundai app not closed");
		}
	}

	public static WebDriver getDriver() {
		return driver;
	}

	public static WebDriverWait webDriverWait() {
		return new WebDriverWait(driver, elementWaitInSeconds);
	}

	public static void WaitElementToBeClickable(WebElement element) {
		webDriverWait().until(ExpectedConditions.elementToBeClickable(element));
	}

	public static void WaitVisibilityOfElement(WebElement element) {
		webDriverWait().until(ExpectedConditions.visibilityOf(element));
	}

	//Tap on element
	public void TapElement(WebElement element) {
		try {
			WaitElementToBeClickable(element);
			element.click();
			logger.info("Element has been tapped");
		} catch (Exception ex) {
			logger.error("Element tapping gets failed");
		}
	}

	//Enter input to textbox
	public void EnterInput(WebElement element, String inputText) {
		try {
			element.clear();
			element.sendKeys(inputText);
			logger.info("Sending input being passed");
		} catch (Exception ex) {
			logger.error("Sending input gets failed");
		}
	}

	//Load property file
	public static Properties loadProperty(String path) {
		try {

			reader = new BufferedReader(new FileReader(path));
			property = new Properties();
			property.load(new FileInputStream(path));
			logger.info("Properties are loaded successfully");
			return property;
		} catch (Exception ex) {
			logger.error("Properties doesn't loaded");
		}
		return null;
	}
	
	
	public static void selectByValue(WebElement element, String option) {
		try {
			Select selectElement = new Select(element);
			selectElement.selectByValue(option);
			Reporter.log("Element is selected through index", true);
		} catch (Exception ex) {
			Reporter.log("Element is  not able to select through index", false);
		}
	}
	
	

	public static void selectByVisibleText(WebElement element, String text) {
		try {
			Select select = new Select(element);
			select.selectByVisibleText(text);
			Reporter.log("Element is selected through Visible text", true);
		} catch (Exception ex) {
			Reporter.log("Element is  not able to select through visible Text", false);
		}
	}
	
	
	
	
	
	
	
	// move to particular element
	public static void actionmove(WebDriver driver, WebElement element) {
		try {
			Actions action = new Actions(driver);
			action.moveToElement(element).build().perform();
			logger.info("Mouse hover an element is successful");
		} catch (Exception ex) {
			logger.error("Mouse hover got failed");
		}
	}

	//Single click
	public void ActionClick(WebElement element) {
		try {
			Actions action = new Actions(driver);
			action.moveToElement(element);
			action.click();
			action.perform();
			logger.info("Mouse hover and single click successful");
		} catch (Exception ex) {
			logger.error("Mouse hover and single click got failed");
		}
	}

	//Double click
	public void ActionDoubleClick(WebElement element) {
		try {
			Actions action = new Actions(driver);
			action.moveToElement(element);
			action.doubleClick();
			action.perform();
			logger.info("Mouse hover and double click successful");
		} catch (Exception ex) {
			logger.error("Mouse hover and double click got failed");
		}
	}
	
	
	
	

}
