package com.Hyundai.Utilities;

public interface IAutoConstant {

	public static final String HYUNDAI = "./src/test/resources/properties/common/appInputs.properties";
	
	
		
}
