package com.Hyundai.testRunner;
import org.junit.AfterClass;
import org.junit.runner.RunWith;
import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;


@RunWith(Cucumber.class)
@CucumberOptions(features = "src/test/java/com/HyundaiModules/Feature",
glue = {"com.HyundaiStepDefinition.test"},
monochrome=true, tags= "@Smoke",dryRun=false,
//plugin ={"pretty", "json:target/cucumber-reports/cucumber.json", "html:target/cucumber-reports/cucumber.html"}
plugin="com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:")

	


public class RunCukesTest {

	
	@AfterClass	
	public static void setup() throws 	Exception
	{
		
	}
    }


